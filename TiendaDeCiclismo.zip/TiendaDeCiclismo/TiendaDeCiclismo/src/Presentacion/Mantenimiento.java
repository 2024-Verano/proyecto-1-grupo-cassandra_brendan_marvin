package Presentacion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * Esta clase se encarga de gestionar los servicios de mantenimiento de bicicletas.
 * Incluye funcionalidades para crear, buscar, modificar y eliminar servicios.
 */
public class Mantenimiento {
    // Atributos
    private int codigoServicio;
    private int codigoCliente;
    private String marcaBicicleta;
    private String descripcionBicicleta;
    private int precio;
    private LocalDate fechaRecibido;
    private LocalDate fechaEntrega;
    private String observaciones;
    private String estado; // Abierto o Cerrado

    // Constructor

    // Métodos setters y getters
    public int getCodigoServicio() {
        return codigoServicio;
    }

    public int getCodigoCliente() {
        return codigoCliente;
    }

    public String getMarcaBicicleta() {
        return marcaBicicleta;
    }

    public String getDescripcionBicicleta() {
        return descripcionBicicleta;
    }

    public int getPrecio() {
        return precio;
    }

    public LocalDate getFechaRecibido() {
        return fechaRecibido;
    }

    public LocalDate getFechaEntrega() {
        return fechaEntrega;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public String getEstado() {
        return estado;
    }

    public void setCodigoServicio(int codigoServicio) {
        this.codigoServicio = codigoServicio;
    }

    public void setCodigoCliente(int codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public void setMarcaBicicleta(String marcaBicicleta) {
        this.marcaBicicleta = marcaBicicleta;
    }

    public void setDescripcionBicicleta(String descripcionBicicleta) {
        this.descripcionBicicleta = descripcionBicicleta;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setFechaRecibido(LocalDate fechaRecibido) {
        this.fechaRecibido = fechaRecibido;
    }

    public void setFechaEntrega(LocalDate fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    // Métodos getters y setters (ya implementados).

    /**
     * Genera un nuevo código de servicio basado en la cantidad de registros existentes.
     * @return Un número entero que representa el próximo código único.
     */
    public static int BuscarId(){
        int id = 1;
        //Cambiar el absolute path por relatives
        try (Scanner sc = new Scanner(new File("mantenimientos.csv"))) {
            // Leer el archivo línea por línea
            while (sc.hasNextLine()) { 
                String linea = sc.nextLine();
                id += 1;  //va sumando las líneas
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error"); // Manejo de errores si el archivo no se encuentra
        }
        return id;
    }
    
    /**
     * Crea un archivo CSV para almacenar los servicios de mantenimiento si no existe.
     */
    public static void crearArchivo() {
        try {
            File archivo = new File("mantenimientos.csv");
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado con éxito: " + archivo.getName());
            } else {
                System.out.println("El archivo ya existe.");
            }
        } catch (IOException ex) {
            System.out.println("Se produjo un error al crear el archivo.");
        }
    }

    /**
     * Agrega un nuevo servicio de mantenimiento al archivo CSV.
     */
    public void agregarMantenimiento() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("mantenimientos.csv", true))) {
            writer.write(this.codigoServicio + ";" + this.codigoCliente + ";" + this.marcaBicicleta + ";" +
                    this.descripcionBicicleta + ";" + this.precio + ";" +
                    this.fechaRecibido + ";" + this.fechaEntrega + ";" + this.observaciones + ";" + this.estado);
            writer.newLine();
            JOptionPane.showMessageDialog(null, "Servicio de mantenimiento agregado con éxito.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo.");
        }
    }

    /**
     * Busca un servicio de mantenimiento por código o cliente.
     * @param codigo Código o identificador único del servicio o cliente.
     * @param necesidad Índice de la columna a buscar (0 para código, 1 para cliente, etc.).
     * @return Un arreglo de cadenas que contiene los detalles del servicio encontrado.
     */
        public String[] BuscarMantenimiento(String codigo, int necesidad){
        String[] partes = {};
        try (Scanner sc = new Scanner(new File("mantenimientos.csv"))) {
            while (sc.hasNextLine()) { 
                String linea = sc.nextLine();
                partes = linea.split(";");
                if (codigo.equals(partes[necesidad])){
                    return partes;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error"); // Manejo de errores si el archivo no se encuentra
        }
        return partes;
    }

    /**
     * Modifica un servicio de mantenimiento en el archivo CSV.
     * @param dato Código del servicio a modificar.
     */
    public void ModificarMantenimiento(String dato){
        File archivo = new File("mantenimientos.csv");
        File archivotemp = new File(archivo.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo));
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivotemp))) {

            String linea;
            String[] partes;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
                partes = linea.split(";");
                
                // Escribir la línea en el archivo temporal si no coincide con la línea a eliminar
                if (!partes[0].trim().equals(dato)) {
                    System.out.println(1);
                    writer.write(linea);
                    writer.newLine(); // Añadir nueva línea
                } else {
                    System.out.println(2);
                    writer.write(this.codigoServicio+";"+this.codigoCliente+";"+this.marcaBicicleta+";"+this.descripcionBicicleta+";"+this.precio+";"+this.fechaRecibido+";"+this.fechaEntrega+";"+this.observaciones+";"+this.estado+";");
                    writer.newLine();
                }
            }
            
            JOptionPane.showMessageDialog(null, "Modificado correctamente");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eliminar el archivo original
        if (!archivo.delete()) {
            System.out.println("No se pudo eliminar el archivo original");
            return;
        }

        // Renombrar el archivo temporal al nombre del archivo original
        if (!archivotemp.renameTo(archivo)) {
            System.out.println("No se pudo renombrar el archivo temporal");
        }

    }

    /**
     * Elimina un servicio de mantenimiento del archivo CSV.
     * @param codigo Código del servicio a eliminar.
     */
    public static void eliminarMantenimiento(int codigo) {
        File archivo = new File("mantenimientos.csv");
        File archivoTemp = new File(archivo.getAbsolutePath() + ".tmp");
        boolean eliminado = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo));
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivoTemp))) {

            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(";");
                if (Integer.parseInt(partes[0]) != codigo) {
                    writer.write(linea);
                    writer.newLine();
                } else {
                    eliminado = true;
                }
            }

            if (eliminado) {
                JOptionPane.showMessageDialog(null, "Servicio de mantenimiento eliminado con éxito.");
            } else {
                JOptionPane.showMessageDialog(null, "Servicio no encontrado.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!archivo.delete()) {
            System.out.println("No se pudo eliminar el archivo original.");
            return;
        }

        if (!archivoTemp.renameTo(archivo)) {
            System.out.println("No se pudo renombrar el archivo temporal.");
        }
    }
}
