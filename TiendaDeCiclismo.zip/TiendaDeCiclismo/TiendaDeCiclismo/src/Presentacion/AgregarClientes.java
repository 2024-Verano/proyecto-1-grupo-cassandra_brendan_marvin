/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Presentacion;

import java.awt.event.ItemEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;


public class AgregarClientes extends javax.swing.JFrame{

    public AgregarClientes() {
        initComponents();
        int id = BuscarId();
        jTextFieldCodigo.setText(Integer.toString(id+1));
    }
    
    
    private boolean ValidarCorreo(String correo) {
        String regex = "^[\\w\\-\\_\\+]+(\\.[\\w\\-\\_]+)*@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(correo);
        return matcher.matches(); // Retorna true si el correo coincide con el patrón
    }

   
    private LocalDate convertirFecha(String fecha) {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
        try {
            LocalDate fechalista = LocalDate.parse(fecha, formato);
            return fechalista;
        } catch (DateTimeParseException e) {
            
            JOptionPane.showMessageDialog(this, "Formato de fecha inválido. Usa 'dd/mm/yyyy'.", "Error", JOptionPane.ERROR_MESSAGE);
            
        }
        LocalDate error = LocalDate.parse("01/01/1900", formato);
        return error;
                
    }
    
    //establece los cantones según provincia
    public String[] canton(String canton){
        String[]veinte = new String[21];
        String[]quince = new String[17];
        String[]ocho = new String[9];
        String[]diez = new String[11];
        String[]once = new String[12];
        String[]trece = new String[14];
        String[]seis = new String[7];
        if (canton.equals("San José")){
            veinte[0] = "Seleccionar";
            veinte[1] = "Acosta";
            veinte[2] = "Alajuelita";
            veinte[3] = "Aserrí";
            veinte[4] = "Coronado";
            veinte[5] = "Curridabat";
            veinte[6] = "Desamparados";
            veinte[7] = "Dota";
            veinte[8] = "Escazú";
            veinte[9] = "Goicoechea";
            veinte[10] = "León Cortés";
            veinte[11] = "Montes de Oca";
            veinte[12] = "Mora";
            veinte[13] = "Moravia";
            veinte[14] = "Pérez Zeledón";
            veinte[15] = "Puriscal";
            veinte[16] = "San José";
            veinte[17] = "Santa Ana";
            veinte[18] = "Tarrazú";
            veinte[19] = "Tibás";
            veinte[20] = "Turrubares";
            return veinte;
        }
        if (canton.equals("Alajuela")){
            quince[0] = "Seleccionar";
            quince[1] = "Alajuela";
            quince[2] = "Atenas";
            quince[3] = "Grecia";
            quince[4] = "Guatuso";
            quince[5] = "Los Chiles";
            quince[6] = "Naranjo";
            quince[7] = "Orotina";
            quince[8] = "Palmares";
            quince[9] = "Poas";
            quince[10] = "Río Cuarto";
            quince[11] = "San Carlos";
            quince[12] = "San Mateo";
            quince[13] = "San Ramón";            
            quince[14] = "Sarchí";
            quince[15] = "Upala";
            quince[16] = "Zarcero";
            return quince;
        }
        if (canton.equals("Cartago")){
            ocho[0] = "Seleccionar";
            ocho[1] = "Alvarado";
            ocho[2] = "Cartago";
            ocho[3] = "El Guarco";
            ocho[4] = "Jiménez";
            ocho[5] = "La Unión";
            ocho[6] = "Oreamuno";
            ocho[7] = "Paraíso";
            ocho[8] = "Turrialba";
            return ocho;
        }
        if (canton.equals("Heredia")){
            diez[0] = "Seleccionar";
            diez[1] = "Barva";
            diez[2] = "Belén";
            diez[3] = "Flores";
            diez[4] = "Heredia";
            diez[5] = "San Isidro";
            diez[6] = "San Pablo";
            diez[7] = "San Rafael";
            diez[8] = "Santa Bárbara";
            diez[9] = "Santo Domingo";
            diez[10] = "Sarapiqui";
            return diez;
        }
        if (canton.equals("Guanacaste")){
            once[0] = "Seleccionar";
            once[1] = "Abangares";
            once[2] = "Bagaces";
            once[3] = "Cañas";
            once[4] = "Carrillo";
            once[5] = "Hojancha";
            once[6] = "La Cruz";
            once[7] = "Liberia";
            once[8] = "Nandayure";
            once[9] = "Nicoya";
            once[10] = "Santa Cruz";
            once[11] = "Tilaran";
            return once;
        }
        if (canton.equals("Puntarenas")){
            trece[0] = "Seleccionar";
            trece[1] = "Buenos Aires";
            trece[2] = "Corredores";
            trece[3] = "Coto Brus";
            trece[4] = "Esparza";
            trece[5] = "Garabito";
            trece[6] = "Golfito";
            trece[7] = "Montes de Oro";
            trece[8] = "Monteverde";
            trece[9] = "Osa";
            trece[10] = "Parrita";
            trece[11] = "Puerto Jiménez";
            trece[12] = "Puntarenas";
            trece[13] = "Quepos";
            return trece;
        }
        if (canton.equals("Limón")){
            seis[0] = "Seleccionar";
            seis[1] = "Guácimo";
            seis[2] = "Limón";
            seis[3] = "Matina";
            seis[4] = "Pococí";
            seis[5] = "Siquirres";
            seis[6] = "Talamanca";
            return seis;
        }
        return veinte;
    }

    //establece los distritos según cantón
    public String[] distrito(String distrito){
        String[]uno = new String[2];
        String[]dos = new String[3];
        String[]tres = new String[4];
        String[]cuatro = new String[5];
        String[]cinco = new String[6];
        String[]seis = new String[7];
        String[]siete = new String[8];
        String[]ocho = new String[9];
        String[]nueve = new String[10];
        String[]once = new String[12];
        String[]doce = new String[13];
        String[]trece = new String[14];
        String[]catorce = new String[15];
        String[]dieciseis = new String[16];
        
        uno[0] = "Seleccionar";
        dos[0] = "Seleccionar";
        tres[0] = "Seleccionar";
        cuatro[0] = "Seleccionar";
        cinco[0] = "Seleccionar";
        seis[0] = "Seleccionar";
        siete[0] = "Seleccionar";
        ocho[0] = "Seleccionar";
        nueve[0] = "Seleccionar";
        once[0] = "Seleccionar";
        doce[0] = "Seleccionar";
        trece[0] = "Seleccionar";
        catorce[0] = "Seleccionar";
        dieciseis[0] = "Seleccionar";
        
        //San José
        if (distrito.equals("San José")){
            once[1] = "Carmen";
            once[2] = "Catedral";
            once[3] = "Hatillo";
            once[4] = "Hospital";
            once[5] = "Mata Redonda";
            once[6] = "Merced";
            once[7] = "Pavas";
            once[8] = "San Francisco de Dos Ríos";
            once[9] = "San Sebastián";
            once[10] = "Uruca";
            once[11] = "Zapote";
            return once;
        }
        if (distrito.equals("Escazú")){
            tres[1] = "Escazú";
            tres[2] = "San Antonio";
            tres[3] = "San Rafael";
            return tres;
        }
        if (distrito.equals("Desamparados")){
            trece[1] = "Damas";
            trece[2] = "Desamparados";
            trece[3] = "Frailes";
            trece[4] = "Gravilias";
            trece[5] = "Los Guido";
            trece[6] = "Patarrá";
            trece[7] = "Rosario";
            trece[8] = "San Antonio";
            trece[9] = "San Cristóbal";
            trece[10] = "San Juan de Dios";
            trece[11] = "San Miguel";
            trece[12] = "San Rafael Abajo";
            trece[13] = "San Rafael Arriba";
            return trece;
        }
        if (distrito.equals("Puriscal")){
            nueve[1] = "Barbacoas";
            nueve[2] = "Candelarita";
            nueve[3] = "Chires";
            nueve[4] = "Desamparaditos";
            nueve[5] = "Grifo Alto";
            nueve[6] = "Mercedes Sur";
            nueve[7] = "San Antonio";
            nueve[8] = "San Rafael";
            nueve[9] = "Santiago";
            return nueve;
        }
        if (distrito.equals("Tarrazú")){
            tres[1] = "San Carlos";
            tres[2] = "San Lorenzo";
            tres[3] = "San Marcos";
            return tres;
        }
        if (distrito.equals("Aserrí")){
            siete[1] = "Aserrí";
            siete[2] = "Legua";
            siete[3] = "Monterrey";
            siete[4] = "Salitrillos";
            siete[5] = "San Gabriel";
            siete[6] = "Tarbaca";
            siete[7] = "Vuelta de Jorco";
            return siete;
        }
        if (distrito.equals("Mora")){
            siete[1] = "Colón";
            siete[2] = "Guayabo";
            siete[3] = "Jaris";
            siete[4] = "Picagres";
            siete[5] = "Piedras Negras";
            siete[6] = "Quitirrisí";
            siete[7] = "Tabarcia";
            return siete;
        }
        if (distrito.equals("Goicoechea")){
            siete[1] = "Calle Blancos";
            siete[2] = "Guadalupe";
            siete[3] = "Ipís";
            siete[4] = "Mata de Plátano";
            siete[5] = "Purral";
            siete[6] = "Rancho Redondo";
            siete[7] = "San Francisco";
            return siete;
        }
        if (distrito.equals("Santa Ana")){
            seis[1] = "Brasil";
            seis[2] = "Piedades";
            seis[3] = "Pozos";
            seis[4] = "Salitral";
            seis[5] = "Santa Ana";
            seis[6] = "Uruca";
            return seis;
        }
        if (distrito.equals("Alajuelita")){
            cinco[1] = "Alajuelita";
            cinco[2] = "Concepción";
            cinco[3] = "San Antonio";
            cinco[4] = "San Felipe";
            cinco[5] = "San Josecito";
            return cinco;
        }
        if (distrito.equals("Coronado")){
            cinco[1] = "Cascajal";
            cinco[2] = "Dulce Nombre de Jesús";
            cinco[3] = "Patalillo";
            cinco[4] = "San Isidro";
            cinco[5] = "San Rafael";
            return cinco;
        }
        if (distrito.equals("Acosta")){
            cinco[1] = "Cangrejal";
            cinco[2] = "Guaitil";
            cinco[3] = "Palmichal";
            cinco[4] = "Sabanillas";
            cinco[5] = "San Ignacio";
            return cinco;
        }
        if (distrito.equals("Tibás")){
            cinco[1] = "Anselmo Llorente";
            cinco[2] = "Cinco Esquinas";
            cinco[3] = "Colima";
            cinco[4] = "León XIII";
            cinco[5] = "San Juan";
            return cinco;
        }
        if (distrito.equals("Moravia")){
            tres[1] = "La Trinidad";
            tres[2] = "San Jerónimo";
            tres[3] = "San Vicente";
            return tres;
        }
        if (distrito.equals("Montes de Oca")){
            cuatro[1] = "Mercedes";
            cuatro[2] = "Sabanilla";
            cuatro[3] = "San Pedro";
            cuatro[4] = "San Rafael";
            return cuatro;
        }
        if (distrito.equals("Turrubares")){
            cinco[1] = "Carara";
            cinco[2] = "San Juan de Mata";
            cinco[3] = "San Luis";
            cinco[4] = "San Pablo";
            cinco[5] = "San Pedro";
            return cinco;
        }
        if (distrito.equals("Dota")){
            tres[1] = "Copey";
            tres[2] = "Jardín";
            tres[3] = "Santa María";
            return tres;
        }
        if (distrito.equals("Curridabat")){
            cuatro[1] = "Curridabat";
            cuatro[2] = "Granadilla";
            cuatro[3] = "Sánchez";
            cuatro[4] = "Tirrases";
            return cuatro;
        }
        if (distrito.equals("Pérez Zeledón")){
            doce[1] = "Barú";
            doce[2] = "Cajón";
            doce[3] = "Daniel Flores";
            doce[4] = "El General";
            doce[5] = "La Amistad";
            doce[6] = "Páramo";
            doce[7] = "Pejibaye";
            doce[8] = "Platanares";
            doce[9] = "Río Nuevo";
            doce[10] = "Rivas";
            doce[11] = "San Isidro de El General";
            doce[12] = "San Pedro";
            return doce;
        }
        if (distrito.equals("León Cortés")){
            seis[1] = "Llano Bonito";
            seis[2] = "San Andrés";
            seis[3] = "San Antonio";
            seis[4] = "San Isidro";
            seis[5] = "San Pablo";
            seis[6] = "Santa Cruz";
            return seis;
        }
        //Alajuela
        if (distrito.equals("Alajuela")){
            catorce[1] = "Alajuela";
            catorce[2] = "Carrizal";
            catorce[3] = "Desamparados";
            catorce[4] = "Garita";
            catorce[5] = "Guácima";
            catorce[6] = "Río Segundo";
            catorce[7] = "Sabanilla";
            catorce[8] = "San Antonio";
            catorce[9] = "San Isidro";
            catorce[10] = "San José";
            catorce[11] = "San Rafael";
            catorce[12] = "Sarapiqui";
            catorce[13] = "Tambor";
            catorce[14] = "Turrúcares";
            return catorce;
        }
        if (distrito.equals("San Ramón")){
            catorce[1] = "Alfaro";
            catorce[2] = "Ángeles";
            catorce[3] = "Concepción";
            catorce[4] = "Peñas Blancas";
            catorce[5] = "Piedades Norte";
            catorce[6] = "Piedades Sur";
            catorce[7] = "San Isidro";
            catorce[8] = "San Juan";
            catorce[9] = "San Lorenzo";
            catorce[10] = "San Rafael";
            catorce[11] = "San Ramón";
            catorce[12] = "Santiago";
            catorce[13] = "Volio";
            catorce[14] = "Zapotal";
            return catorce;
        }
        if (distrito.equals("Grecia")){
            siete[1] = "Bolivar";
            siete[2] = "Grecia";
            siete[3] = "Puente de Piedra";
            siete[4] = "San Isidro";
            siete[5] = "San José";
            siete[6] = "San Roque";
            siete[7] = "Tacares";
            return siete;
        }
        if (distrito.equals("San Mateo")){
            cuatro[1] = "Desmonte";
            cuatro[2] = "Jesús María";
            cuatro[3] = "Labrador";
            cuatro[4] = "San Mateo";
            return cuatro;
        }
        if (distrito.equals("Atenas")){
            ocho[1] = "Atenas";
            ocho[2] = "Concepción";
            ocho[3] = "Escobal";
            ocho[4] = "Jesús";
            ocho[5] = "Mercedes";
            ocho[6] = "San Isidro";
            ocho[7] = "San José";
            ocho[8] = "Santa Eulalia";
            
            return ocho;
        }
        if (distrito.equals("Naranjo")){
            ocho[1] = "Cirrí Sur";
            ocho[2] = "El Rosario";
            ocho[3] = "Naranjo";
            ocho[4] = "Palmitos";
            ocho[5] = "San Jerónimo";
            ocho[6] = "San José";
            ocho[7] = "San Juan";
            ocho[8] = "San Miguel";
            return ocho;
        }
        if (distrito.equals("Palmares")){
            siete[1] = "Buenos Aires";
            siete[2] = "Candelaria";
            siete[3] = "Esquipulas";
            siete[4] = "La Granja";
            siete[5] = "Palmares";
            siete[6] = "Santiago";
            siete[7] = "Zaragoza";
            return siete;
        }
        if (distrito.equals("Poas")){
            cinco[1] = "Carrillos";
            cinco[2] = "Sabana Redonda";
            cinco[3] = "San Juan";
            cinco[4] = "San Pedro";
            cinco[5] = "San Rafael";
            return cinco;
        }
        if (distrito.equals("Orotina")){
            cinco[1] = "Coyolar";
            cinco[2] = "El Mastate";
            cinco[3] = "Hacienda Vieja";
            cinco[4] = "La Ceiba";
            cinco[5] = "Orotina";
            return cinco;
        }
        if (distrito.equals("San Carlos")){
            trece[1] = "Aguas Zarcas";
            trece[2] = "Buenavista";
            trece[3] = "Cutris";
            trece[4] = "Florencia";
            trece[5] = "La Fortuna";
            trece[6] = "La Palmera";
            trece[7] = "La Tigra";
            trece[8] = "Monterrey";
            trece[9] = "Pital";
            trece[10] = "Pocosol";
            trece[11] = "Quesada";
            trece[12] = "Venado";
            trece[13] = "Venecia";
            return trece;
        }
        if (distrito.equals("Zarcero")){
            siete[1] = "Brisas";
            siete[2] = "Guadalupe";
            siete[3] = "Laguna";
            siete[4] = "Palmira";
            siete[5] = "Tapesco";
            siete[6] = "Zapote";
            siete[7] = "Zarcero";
            return siete;
        }
        if (distrito.equals("Sarchí")){
            cinco[1] = "Rodríguez";
            cinco[2] = "San Pedro";
            cinco[3] = "Sarchí Norte";
            cinco[4] = "Sarchí Sur";
            cinco[5] = "Toro Amarillo";
            return cinco;
        }
        if (distrito.equals("Upala")){
            ocho[1] = "Aguas Claras";
            ocho[2] = "Bijagua";
            ocho[3] = "Canalete";
            ocho[4] = "Delicias";
            ocho[5] = "Dos Ríos";
            ocho[6] = "San José o Pizote";
            ocho[7] = "Upala";
            ocho[8] = "Yolillal";
            return ocho;
        }
        if (distrito.equals("Los Chiles")){
            cuatro[1] = "Caño Negro";
            cuatro[2] = "El Amparo";
            cuatro[3] = "Los Chiles";
            cuatro[4] = "San Jorge";
            return cuatro;
        }
        if (distrito.equals("Guatuso")){
            cuatro[1] = "Buenavista";
            cuatro[2] = "Cote";
            cuatro[3] = "Katira";
            cuatro[4] = "San Rafael";
            return cuatro;
        }
        if (distrito.equals("Río Cuarto")){
            tres[1] = "Río Cuarto";
            tres[2] = "Santa Isabel";
            tres[3] = "Santa Rita";
            return tres;
        }
        //Cartago
        if (distrito.equals("Cartago")){
            once[1] = "Aguacaliente";
            once[2] = "Carmen";
            once[3] = "Corralillo";
            once[4] = "Dulce Nombre";
            once[5] = "Guadalupe";
            once[6] = "Llano Grande";
            once[7] = "Occidental";
            once[8] = "Oriental";
            once[9] = "Quebradilla";
            once[10] = "San Nicolás";
            once[11] = "Tierra Blanca";
            return once;
        }
        if (distrito.equals("Paraíso")){
            seis[1] = "Birrisito";
            seis[2] = "Cachí";
            seis[3] = "Llanos de Santa Lucía";
            seis[4] = "Orosi";
            seis[5] = "Paraíso";
            seis[6] = "Santiago";
            return seis;
        }
        if (distrito.equals("La Unión")){
            ocho[1] = "Concepción";
            ocho[2] = "Dulce Nombre";
            ocho[3] = "Río Azul";
            ocho[4] = "San Diego";
            ocho[5] = "San Juan";
            ocho[6] = "San Rafael";
            ocho[7] = "San Ramón";
            ocho[8] = "Tres Ríos";
            return ocho;
        }
        if (distrito.equals("Jiménez")){
            cuatro[1] = "Juan Viñas";
            cuatro[2] = "La Victoria";
            cuatro[3] = "Pejibaye";
            cuatro[4] = "Tucurrique";
            return cuatro;
        }
        if (distrito.equals("Turrialba")){
            doce[1] = "Chirripó";
            doce[2] = "La Isabel";
            doce[3] = "La Suiza";
            doce[4] = "Pavones";
            doce[5] = "Peralta";
            doce[6] = "Santa Cruz";
            doce[7] = "Santa Rosa";
            doce[8] = "Santa Teresita";
            doce[9] = "Tayutic";
            doce[10] = "Tres Equis";
            doce[11] = "Tuis";
            doce[12] = "Turrialba";
            return doce;
        }
        if (distrito.equals("Alvarado")){
            tres[1] = "Capellades";
            tres[2] = "Cervantes";
            tres[3] = "Pacayas";
            return tres;
        }
        if (distrito.equals("Oreamuno")){
            cinco[1] = "Cipreses";
            cinco[2] = "Cot";
            cinco[3] = "Potrero Cerrado";
            cinco[4] = "San Rafael";
            cinco[5] = "Santa Rosa";
            return cinco;
        }
        if (distrito.equals("El Guarco")){
            cuatro[1] = "El Tejar";
            cuatro[2] = "Patio de Agua";
            cuatro[3] = "San Isidro";
            cuatro[4] = "Tobosi";
            return cuatro;
        }
        //Heredia
        if (distrito.equals("Heredia")){
            cinco[1] = "Heredia";
            cinco[2] = "Mercedes";
            cinco[3] = "San Francisco";
            cinco[4] = "Ulloa";
            cinco[5] = "Varablanca";
            return cinco;
        }
        if (distrito.equals("Barva")){
            siete[1] = "Barva";
            siete[2] = "Puente Salas";
            siete[3] = "San José de la Montaña";
            siete[4] = "San Pablo";
            siete[5] = "San Pedro";
            siete[6] = "San Roque";
            siete[7] = "Santa Lucía";
            return siete;
        }
        if (distrito.equals("Santo Domingo")){
            ocho[1] = "Pará";
            ocho[2] = "Paracito";
            ocho[3] = "San Miguel";
            ocho[4] = "San Vicente";
            ocho[5] = "Santa Rosa";
            ocho[6] = "Santo Domingo";
            ocho[7] = "Santo Tomás";
            ocho[8] = "Tures";
            return ocho;
        }
        if (distrito.equals("Santa Bárbara")){
            seis[1] = "Jesús";
            seis[2] = "Purabá";
            seis[3] = "San Juan";
            seis[4] = "San Pedro";
            seis[5] = "Santa Bárbara ";
            seis[6] = "Santo Domingo";
            return seis;
        }
        if (distrito.equals("San Rafael")){
            cinco[1] = "Ángeles";
            cinco[2] = "Concepción";
            cinco[3] = "San Josecito";
            cinco[4] = "San Rafael";
            cinco[5] = "Santiago";
            return cinco;
        }
        if (distrito.equals("San Isidro")){
            cuatro[1] = "Concepción";
            cuatro[2] = "San Francisco";
            cuatro[3] = "San Isidro";
            cuatro[4] = "San José";
            return cuatro;
        }
        if (distrito.equals("Belén")){
            tres[1] = "La Asunción";
            tres[2] = "La Ribera";
            tres[3] = "San Antonio";
            return tres;
        }
        if (distrito.equals("Flores")){
            tres[1] = "Barrantes";
            tres[2] = "Llorente";
            tres[3] = "San Joaquín";
            return tres;
        }
        if (distrito.equals("San Pablo")){
            dos[1] = "Rincón de Sabanilla";
            dos[2] = "San Pablo";
            return dos;
        }
        if (distrito.equals("Sarapiqui")){
            cinco[1] = "Cureña";
            cinco[2] = "La Virgen";
            cinco[3] = "Las Horquetas";
            cinco[4] = "Llanuras de Gaspar";
            cinco[5] = "Puerto Viejo";
            return cinco;
        }
        //Guanacaste
        if (distrito.equals("Liberia")){
            cinco[1] = "Cañas Dulces";
            cinco[2] = "Curubandé";
            cinco[3] = "Liberia";
            cinco[4] = "Mayorga";
            cinco[5] = "Nacascolo";
            return cinco;
        }
        if (distrito.equals("Nicoya")){
            siete[7] = "Belén de Nosarita";
            siete[2] = "Mansión";
            siete[1] = "Nicoya";
            siete[6] = "Nosara";
            siete[4] = "Quebrada Honda";
            siete[5] = "Sámara";
            siete[3] = "San Antonio";
            return siete;
        }
        if (distrito.equals("Santa Cruz")){
            nueve[1] = "Bolsón";
            nueve[2] = "Cabo Velas";
            nueve[3] = "Cartagena";
            nueve[4] = "Cuajiniquil";
            nueve[5] = "Diriá";
            nueve[6] = "Santa Cruz";
            nueve[7] = "Tamarindo";
            nueve[8] = "Tempate";
            nueve[9] = "Veintisiete de Abril";
            return nueve;
        }
        if (distrito.equals("Bagaces")){
            cuatro[1] = "Bagaces";
            cuatro[2] = "La Fortuna";
            cuatro[3] = "Mogote";
            cuatro[4] = "Río Naranjo";
            return cuatro;
        }
        if (distrito.equals("Carrillo")){
            cuatro[1] = "Belén";
            cuatro[2] = "Filadelfia";
            cuatro[3] = "Palmira";
            cuatro[4] = "Sardinal";
            return cuatro;
        }
        if (distrito.equals("Cañas")){
            cinco[1] = "Bebedero";
            cinco[2] = "Cañas";
            cinco[3] = "Palmira";
            cinco[4] = "Porozal";
            cinco[5] = "San Miguel";
            return cinco;
        }
        if (distrito.equals("Abangares")){
            cuatro[1] = "Colorado";
            cuatro[2] = "Las Juntas";
            cuatro[3] = "San Juan";
            cuatro[4] = "Sierra";
            return cuatro;
        }
        if (distrito.equals("Tilaran")){
            ocho[1] = "Arenal";
            ocho[2] = "Cabeceras";
            ocho[3] = "Líbano";
            ocho[4] = "Quebrada Grande";
            ocho[5] = "Santa Rosa";
            ocho[6] = "Tierras Morenas";
            ocho[7] = "Tilarán";
            ocho[8] = "Tronadora";
            return ocho;
        }
        if (distrito.equals("Nandayure")){
            seis[1] = "Bejuco";
            seis[2] = "Carmona";
            seis[3] = "Porvenir";
            seis[4] = "San Pablo";
            seis[5] = "Santa Rita";
            seis[6] = "Zapotal";
            return seis;
        }
        if (distrito.equals("La Cruz")){
            cuatro[1] = "La Cruz";
            cuatro[2] = "La Garita";
            cuatro[3] = "Santa Cecilia";
            cuatro[4] = "Santa Elena";
            return cuatro;
        }
        if (distrito.equals("Hojancha")){
            cinco[1] = "Hojancha";
            cinco[2] = "Huacas";
            cinco[3] = "Matambú";
            cinco[4] = "Monte Romo";
            cinco[5] = "Puerto Carrillo";
            return cinco;
        }
        //Puntarenas
        if (distrito.equals("Puntarenas")){
            dieciseis[1] = "Acapulco";
            dieciseis[2] = "Arancibia";
            dieciseis[3] = "Barranca";
            dieciseis[4] = "Chacarita";
            dieciseis[5] = "Chira";
            dieciseis[6] = "Chomes";
            dieciseis[7] = "Cóbano";
            dieciseis[8] = "El Roble";
            dieciseis[9] = "Guacimal";
            dieciseis[10] = "Isla del Coco";
            dieciseis[11] = "Lepanto";
            dieciseis[12] = "Manzanillo";
            dieciseis[13] = "Paquera";
            dieciseis[14] = "Pitahaya";
            dieciseis[15] = "Puntarenas";
            return dieciseis;
        }
        if (distrito.equals("Esparza")){
            seis[1] = "Caldera";
            seis[2] = "Espíritu Santo";
            seis[3] = "Macacona";
            seis[4] = "San Jerónimo";
            seis[5] = "San Juan Grande";
            seis[6] = "San Rafael";
            return seis;
        }
        if (distrito.equals("Buenos Aires")){
            nueve[1] = "Biolley";
            nueve[2] = "Boruca";
            nueve[3] = "Brunka";
            nueve[4] = "Buenos Aires";
            nueve[5] = "Chánguena";
            nueve[6] = "Colinas";
            nueve[7] = "Pilas";
            nueve[8] = "Potrero Grande";
            nueve[9] = "Volcán";
            return nueve;
        }
        if (distrito.equals("Montes de Oro")){
            tres[1] = "La Unión";
            tres[2] = "Miramar";
            tres[3] = "San Isidro";
            return tres;
        }
        if (distrito.equals("Osa")){
            seis[1] = "Bahía Drake";
            seis[2] = "Bahía Ballena";
            seis[3] = "Palmar";
            seis[4] = "Piedras Blancas";
            seis[5] = "Puerto Cortés";
            seis[6] = "Sierpe";
            return seis;
        }
        if (distrito.equals("Quepos")){
            tres[1] = "Naranjito";
            tres[2] = "Quepos";
            tres[3] = "Savegre";
            return tres;
        }
        if (distrito.equals("Golfito")){
            tres[1] = "Golfito";
            tres[2] = "Guaycará";
            tres[3] = "Pavón";
            return tres;
        }
        if (distrito.equals("Coto Brus")){
            seis[1] = "Aguabuena";
            seis[2] = "Gutiérrez Braun";
            seis[3] = "Limoncito";
            seis[4] = "Pittier";
            seis[5] = "Sabalito";
            seis[6] = "San Vito";
            return seis;
        }
        if (distrito.equals("Parrita")){
            uno[1] = "Parrita";
            return uno;
        }
        if (distrito.equals("Corredores")){
            cuatro[1] = "Canoas";
            cuatro[2] = "Corredor";
            cuatro[3] = "La Cuesta";
            cuatro[4] = "Laurel";
            return cuatro;
        }
        if (distrito.equals("Garabito")){
            tres[1] = "Jacó";
            tres[2] = "Lagunillas";
            tres[3] = "Tárcoles";
            return tres;
        }
        if (distrito.equals("Monteverde")){
            uno[1] = "Monteverde";
            return uno;
        }
        if (distrito.equals("Puerto Jiménez")){
            uno[1] = "Puerto Jiménez";
            return uno;
        }
        //Limón
        if (distrito.equals("Limón")){
            cuatro[1] = "Limón";
            cuatro[2] = "Matama";
            cuatro[3] = "Río Blanco";
            cuatro[4] = "Valle La Estrella";
            return cuatro;
        }
        if (distrito.equals("Pococí")){
            siete[1] = "Cariari";
            siete[2] = "Colorado";
            siete[3] = "Guápiles";
            siete[4] = "Jiménez";
            siete[5] = "La Colonia";
            siete[6] = "Rita";
            siete[7] = "Roxana";
            return siete;
        }
        if (distrito.equals("Siquirres")){
            siete[1] = "Alegría";
            siete[2] = "El Cairo";
            siete[3] = "Florida";
            siete[4] = "Germania";
            siete[5] = "Pacuarito";
            siete[6] = "Reventazón";
            siete[7] = "Siquirres";
            return siete;
        }
        if (distrito.equals("Talamanca")){
            cuatro[1] = "Bratsi";
            cuatro[2] = "Cahuita";
            cuatro[3] = "Sixaola";
            cuatro[4] = "Telire";
            return cuatro;
        }
        if (distrito.equals("Matina")){
            tres[1] = "Batán";
            tres[2] = "Carrandí";
            tres[3] = "Matina";
            return tres;
        }
        if (distrito.equals("Guácimo")){
            cinco[1] = "Duacarí";
            cinco[2] = "Guácimo";
            cinco[3] = "Mercedes";
            cinco[4] = "Pocora";
            cinco[5] = "Río Jiménez";
            return cinco;
        }
        return tres;
    }

    public boolean TelefonoValido(){
        if (jTextFieldTelefono.getText().trim().length() == 8){ //se valida que el teléfono sea de 8 dígitos 
            int inicio = Integer.parseInt(jTextFieldTelefono.getText());
            inicio = inicio / 10000000;
            if (inicio%2 == 0){ //se valida que el teléfono empiece en 2, 4, 6 u 8
                return true;
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese un número de teléfono válido (iniciando en 2, 4, 6 u 8)");
            }
        }else{
            JOptionPane.showMessageDialog(null, "Ingrese un número de teléfono válido (ocho dígitos)");
        }
        return false;
    }
    
    public int BuscarId(){
        int id = 0;
        try (Scanner sc = new Scanner(new File("clientes.csv"))) {
            // Leer el archivo línea por línea
            while (sc.hasNextLine()) { 
                String linea = sc.nextLine();
                id += 1;  //va sumando las líneas
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error"); // Manejo de errores si el archivo no se encuentra
        }
        
        return id;
    }
    
    
    
    /*
    
    
    */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jComboBoxDistrito = new javax.swing.JComboBox<>();
        jComboBoxCanton = new javax.swing.JComboBox<>();
        jComboBoxProvincia = new javax.swing.JComboBox<>();
        jButtonAgregar = new javax.swing.JButton();
        jTextFieldApellidos = new javax.swing.JTextField();
        jTextFieldCodigo = new javax.swing.JTextField();
        jTextFieldNombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldTelefono = new javax.swing.JTextField();
        jTextFieldFechaNacimiento = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jButtonLimpiar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextFieldCorreo = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Agregar Clientes");

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jComboBoxDistrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxDistritoActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBoxDistrito, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 260, 140, -1));

        jComboBoxCanton.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxCantonItemStateChanged(evt);
            }
        });
        jComboBoxCanton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCantonActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBoxCanton, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 260, 140, -1));

        jComboBoxProvincia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Alajuela", "Cartago", "Guanacaste", "Heredia", "Limón", "Puntarenas", "San José" }));
        jComboBoxProvincia.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxProvinciaItemStateChanged(evt);
            }
        });
        jComboBoxProvincia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxProvinciaActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBoxProvincia, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 220, 140, 20));

        jButtonAgregar.setText("Agregar");
        jButtonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgregarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, -1, -1));
        jPanel1.add(jTextFieldApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 180, 140, -1));

        jTextFieldCodigo.setEditable(false);
        jTextFieldCodigo.setEnabled(false);
        jTextFieldCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCodigoActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 140, -1));
        jPanel1.add(jTextFieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 140, 140, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Agregar Clientes");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 40, -1, -1));
        jPanel1.add(jTextFieldTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 180, 140, -1));
        jPanel1.add(jTextFieldFechaNacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 300, 140, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Nombre:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 140, 90, 20));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Telefono:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 180, 90, 20));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Provincia:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 220, 90, 20));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Distrito:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 260, 90, 20));

        jButtonLimpiar.setText("Limpiar");
        jButtonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 350, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/}.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 350, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Codigo:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 90, 20));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Apellidos:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 90, 20));
        jPanel1.add(jTextFieldCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 140, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Correo:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, 90, 20));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Cantón:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 90, 20));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Fecha de nacimiento:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 150, 20));

        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 350, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/teleopreador.jpg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxProvinciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxProvinciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxProvinciaActionPerformed

    private void jComboBoxCantonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCantonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCantonActionPerformed

    private void jComboBoxDistritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxDistritoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxDistritoActionPerformed

    //Boton Limpiar
    private void jButtonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLimpiarActionPerformed
        //Restablece los valores
        
        int id = BuscarId();
        jTextFieldCodigo.setText(Integer.toString(id+1));
        jTextFieldApellidos.setText("");
        jTextFieldCorreo.setText("");
        jTextFieldFechaNacimiento.setText("");
        jTextFieldNombre.setText("");
        jTextFieldTelefono.setText("");
        jComboBoxProvincia.setSelectedIndex(0);
        jComboBoxCanton.removeAllItems();
        jComboBoxDistrito.removeAllItems();
    }//GEN-LAST:event_jButtonLimpiarActionPerformed

    //Boton Agregar
    private void jButtonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgregarActionPerformed

        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate fechalista = LocalDate.now();
        LocalDate error = LocalDate.of(1900, 1, 1);
        int telefono;
        int id = BuscarId();
        
        //se toman los datos sin espacios en los extremos
        String nombre = jTextFieldNombre.getText().trim();
        String apellidos = jTextFieldApellidos.getText().trim();
        String provincia = (String) jComboBoxProvincia.getSelectedItem();
        String canton = (String) jComboBoxCanton.getSelectedItem();
        String distrito = (String) jComboBoxDistrito.getSelectedItem();
        String fecha = jTextFieldFechaNacimiento.getText().trim();        
        String correo = jTextFieldCorreo.getText().trim();
        
        System.out.println(fecha);
        
        //se validan uno a uno los datos
        if (nombre.equals("")){
            JOptionPane.showMessageDialog(null, "Ingrese su nombre");
        } else {
            if (apellidos.equals("")){
                JOptionPane.showMessageDialog(null, "Ingrese al menos un apellido");
            } else {
                if (jTextFieldTelefono.getText().trim().equals("")){
                    JOptionPane.showMessageDialog(null, "Ingrese su número de teléfono");
                } else {
                    if (TelefonoValido() == true){
                        telefono = Integer.parseInt(jTextFieldTelefono.getText());
                        if (correo.equals("")){
                            JOptionPane.showMessageDialog(null, "Ingrese su correo");
                        } else {
                            if (ValidarCorreo(correo) == false){
                                jTextFieldCorreo.requestFocus();
                                JOptionPane.showMessageDialog(null, "Digite otro correo con formato válido");
                            } else {
                                if (provincia == null || provincia.equals("Seleccionar")){
                                    JOptionPane.showMessageDialog(null, "Seleccione su provincia");
                                } else {
                                    if (canton == null || canton.equals("Seleccionar")){
                                        JOptionPane.showMessageDialog(null, "Seleccione su canton");
                                    } else {
                                        if (distrito == null || distrito.equals("Seleccionar")){
                                            JOptionPane.showMessageDialog(null, "Seleccione su distrito");
                                        } else {
                                            if (fecha.equals("")){
                                                    JOptionPane.showMessageDialog(null, "Ingrese su fecha de nacimiento");
                                            } else {
                                                fechalista = convertirFecha(fecha);
                                                if (fechalista.compareTo(error) != 0){
                                                    //después de validar todos los datos, porcedemos a crear el objeto cliente
                                                    Clientes cliente = new Clientes();
                                                    cliente.setIdCliente(id+1);
                                                    cliente.setNombre(nombre);
                                                    cliente.setApellidos(apellidos);
                                                    cliente.setTelefono(telefono);
                                                    cliente.setCorreo(correo);
                                                    cliente.setProvincia(provincia);
                                                    cliente.setCanton(canton);
                                                    cliente.setDistrito(distrito);
                                                    cliente.setFecha(fechalista);
                                                    
                                                    JOptionPane.showMessageDialog(null, "Cliente agregado");
                                                    
                                                    
                                                    cliente.AgregarCliente();  
                                                    
                                                    
                                                    //volvemos los valores
                                                    jTextFieldApellidos.setText("");
                                                    jTextFieldCorreo.setText("");
                                                    jTextFieldCodigo.setText(Integer.toString(id+2));
                                                    jTextFieldFechaNacimiento.setText("");
                                                    jTextFieldNombre.setText("");
                                                    jTextFieldTelefono.setText("");
                                                    jComboBoxProvincia.setSelectedIndex(0);
                                                    jComboBoxCanton.removeAllItems();
                                                    jComboBoxDistrito.removeAllItems();
                                                }    
                                            }
                                        }
                                    }    
                                }        
                            }
                        }         
                    }
                }    
            }    
        }
    }//GEN-LAST:event_jButtonAgregarActionPerformed

    private void jTextFieldCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldCodigoActionPerformed

    private void jComboBoxProvinciaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxProvinciaItemStateChanged
        if (evt.getStateChange() == ItemEvent.SELECTED){
            if(this.jComboBoxProvincia.getSelectedIndex()>0){
                this.jComboBoxCanton.setModel(new DefaultComboBoxModel(this.canton(this.jComboBoxProvincia.getSelectedItem().toString())));
            }
        }
    }//GEN-LAST:event_jComboBoxProvinciaItemStateChanged

    private void jComboBoxCantonItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxCantonItemStateChanged
        if (evt.getStateChange() == ItemEvent.SELECTED){
            if(this.jComboBoxCanton.getSelectedIndex()>0){
                this.jComboBoxDistrito.setModel(new DefaultComboBoxModel(this.distrito(this.jComboBoxCanton.getSelectedItem().toString())));
            }
        }
    }//GEN-LAST:event_jComboBoxCantonItemStateChanged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        MenuPrincipal ventana = new MenuPrincipal();
        ventana.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AgregarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AgregarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AgregarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AgregarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgregarClientes().setVisible(true);
                
                
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonAgregar;
    private javax.swing.JButton jButtonLimpiar;
    private javax.swing.JComboBox<String> jComboBoxCanton;
    private javax.swing.JComboBox<String> jComboBoxDistrito;
    private javax.swing.JComboBox<String> jComboBoxProvincia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextFieldApellidos;
    private javax.swing.JTextField jTextFieldCodigo;
    private javax.swing.JTextField jTextFieldCorreo;
    private javax.swing.JTextField jTextFieldFechaNacimiento;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldTelefono;
    // End of variables declaration//GEN-END:variables
}
