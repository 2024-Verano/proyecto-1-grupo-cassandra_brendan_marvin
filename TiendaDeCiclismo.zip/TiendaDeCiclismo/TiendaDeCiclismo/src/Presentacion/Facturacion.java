
package Presentacion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * Gestiona las facturas, incluyendo su creación, registro, búsqueda y anulación.
 * También incluye el manejo de detalles asociados a los artículos de cada factura.
 */
public class Facturacion {
    //Atributos factura
    private int idFactura;
    private int idCliente;
    private LocalDate fechaRecibido;
    private String estado;
    private int subtotal;
    private int impuesto;
    private int total;
    
    //Atributos detalle
    
    private int numFactura;
    private int idArticulo;
    private int cantidad;
    private int precio;
    private int totalArticulos;
    
    // Métodos SET

    /**
     * Asigna la fecha de recepción de la factura.
     * @param fecha Fecha en formato LocalDate.
     */
    public void setFecha(LocalDate fecha){
        this.fechaRecibido = fecha;
    }
    /**
     * Asigna el ID de la factura.
     * @param idFactura Identificador único de la factura.
     */
    public void setIdFactura(int idFactura){
        this.idFactura = idFactura;
    }
    public void setIdCliente(int id){
        this.idCliente = id;
    }
    public void setEstado(String estado){
        this.estado = estado;
    }
    public void setSubtotal(int sub){
        this.subtotal = sub;
    }
    public void setImpuesto(int impu){
        this.impuesto = impu;
    }
    public void setTotalFactura(int total){
        this.total = total;
    }
    public void setArticulo(int articulo){
        this.idArticulo = articulo;
    }
    public void setCantidad(int cantidad){
        this.cantidad = cantidad;
    }
    public void setPrecio(int precio){
        this.precio = precio;
    }
    public void setTotalArticulos(int articulos){
        this.totalArticulos = articulos;
    }
    public void setNumFactura(int numFactura){
        this.numFactura = numFactura;
    }
    // (Se incluyen métodos SET para cada atributo con documentación similar...)      
    
    
    // Métodos principales

    /**
     * Crea el archivo "facturas.csv" si no existe.
     * Utilizado para registrar las facturas.
     */
    public void CrearArchivo(){
        try {
            File archivo = new File("facturas.csv");
            
            //vamos a verificar si el archivo existe
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado con éxito: " + archivo.getName());
            } else {
                System.out.println("El archivo ya existe.");
            }
            
        } catch (IOException ex) {
            System.out.println("Se produjo un error");
        }
    }

    /**
     * Agrega una nueva factura al archivo "facturas.csv".
     * Los datos se escriben en formato delimitado por punto y coma (;).
     */    
    public void AgregarFactura(){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("facturas.csv", true))) {
            writer.write(this.idFactura+";"+this.idCliente+";"+this.fechaRecibido+";"+this.estado+";"+this.subtotal+";"+this.impuesto+";"+this.total+";"+this.idArticulo+";"+this.numFactura+";"+this.cantidad+";"+this.precio+";"+this.totalArticulos+";");
            writer.newLine();  // Nueva línea
        } catch (IOException e) {
            System.out.println("Error");  // Manejo de errores si el archivo no se puede escribir
        }
    }

    /**
     * Busca una factura en el archivo "facturas.csv" utilizando un criterio específico.
     * @param codigo Valor del criterio de búsqueda (ID, cliente, etc.).
     * @param necesidad Índice de la columna que se usará para la búsqueda.
     * @return Un arreglo con los datos de la factura si se encuentra; vacío en caso contrario.
     */    
    public String[] BuscarFactura(String codigo, int necesidad){
        String[] partes = {};
        try (Scanner sc = new Scanner(new File("facturas.csv"))) {
            while (sc.hasNextLine()) { 
                String linea = sc.nextLine();
                partes = linea.split(";");
                if (codigo.equals(partes[necesidad])){
                    return partes;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error"); // Manejo de errores si el archivo no se encuentra
        }
        return partes;
    }

    /**
     * Anula una factura en el archivo "facturas.csv".
     * El estado de la factura se actualiza a "Anulado".
     * @param dato ID de la factura que se desea anular.
     */    
    public void AnularFactura(String dato){
        File archivo = new File("facturas.csv");
        File archivotemp = new File(archivo.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo));
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivotemp))) {

            String linea;
            String[] partes;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
                partes = linea.split(";");
                
                // Escribir la línea en el archivo temporal si no coincide con la línea a eliminar
                if (!partes[0].trim().equals(dato)) {
                    writer.write(linea);
                    writer.newLine(); // Añadir nueva línea
                } else {
                    writer.write(this.idFactura+";"+this.idCliente+";"+this.fechaRecibido+";"+"Anulado;"+this.subtotal+";"+this.impuesto+";"+this.total+";"+this.idArticulo+";"+this.numFactura+";"+this.cantidad+";"+this.precio+";"+this.totalArticulos+";");
                    writer.newLine();
                }
            }
            JOptionPane.showMessageDialog(null, "Anulado correctamente");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eliminar el archivo original
        if (!archivo.delete()) {
            System.out.println("No se pudo eliminar el archivo original");
            return;
        }

        // Renombrar el archivo temporal al nombre del archivo original
        if (!archivotemp.renameTo(archivo)) {
            System.out.println("No se pudo renombrar el archivo temporal");
        }

    }
    
    
    
    
}
