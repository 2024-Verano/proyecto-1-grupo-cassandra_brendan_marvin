package Presentacion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * Gestiona la información de los clientes y las operaciones relacionadas, 
 * como agregar, modificar, buscar y eliminar clientes en un archivo CSV.
 */
public class Clientes {

    /**
     * Verifica si existe un cliente con un ID específico.
     * @param valueOf El ID del cliente en formato String.
     * @return true si el cliente existe, false en caso contrario.
     * @throws UnsupportedOperationException si el método no está implementado.
     */
    static boolean existeIdCliente(String valueOf) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    //Atributos
    private int idCliente;
    private String nombre;
    private String apellidos;
    private int telefono;
    private String correo;
    private String provincia;
    private String canton;
    private String distrito;
    private LocalDate fecha;
    
    // Métodos GET
    /**
     * Obtiene el ID del cliente.
     * @return El ID del cliente.
     */
    // (Se repiten los métodos GET para los demás atributos con su respectiva documentación...)
    public int getIdCliente(){
        return idCliente;
    }
    public int getTelefono(){
        return telefono;
    }
    public LocalDate getFecha(){
        return fecha;
    }
    public String getNombre(){
        return nombre;
    }
    public String getApellidos(){
        return apellidos;
    }
    public String getCorreo(){
        return correo;
    }
    public String getProvincia(){
        return provincia;
    }
    public String getCanton(){
        return canton;
    }
    public String getDistrito(){
        return distrito;
    }
  
    // Métodos SET
    /**
     * Asigna una nueva fecha al cliente.
     * @param fecha La fecha de tipo LocalDate a asignar.
     */
    // (Se repiten los métodos SET para los demás atributos con su respectiva documentación...)
    public void setFecha(LocalDate fecha){
        this.fecha = fecha;
    }
    public void setIdCliente(int idCliente){
        this.idCliente = idCliente;
    }
    public void setTelefono(int telefono){
        this.telefono = telefono;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public void setApellidos(String apellidos){
        this.apellidos = apellidos;
    }
    public void setCorreo(String correo){
        this.correo = correo;
    }
    public void setProvincia(String provincia){
        this.provincia = provincia;
    }
    public void setDistrito(String distrito){
        this.distrito = distrito;
    }
    public void setCanton(String canton){
        this.canton = canton;
    }
    
    /**
     * Agrega un cliente al archivo "clientes.csv".
     * La información del cliente se escribe en formato delimitado por punto y coma (;).
     */    
    public void AgregarCliente(){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("clientes.csv", true))) {
            writer.write(this.idCliente+";"+this.nombre+";"+this.apellidos+";"+this.telefono+";"+this.correo+";"+this.provincia+";"+this.canton+";"+this.distrito+";"+this.fecha+";");
            writer.newLine();  // Nueva línea
        } catch (IOException e) {
            System.out.println("Error");  // Manejo de errores si el archivo no se puede escribir
        }
    }

    /**
     * Crea el archivo "clientes.csv" si no existe.
     */    
    public void CrearArchivo(){
        try {
            File archivo = new File("clientes.csv");
            
            //vamos a verificar si el archivo existe
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado con éxito: " + archivo.getName());
            } else {
                System.out.println("El archivo ya existe.");
            }
            
        } catch (IOException ex) {
            System.out.println("Se produjo un error");
        }
    }

    /**
     * Busca un cliente por código en el archivo "clientes.csv".
     * @param codigo El código del cliente a buscar.
     * @param necesidad La posición en la línea del archivo que se usará para buscar.
     * @return Un arreglo con los datos del cliente si se encuentra; vacío en caso contrario.
     */    
    public String[] BuscarCliente(String codigo, int necesidad){
        String[] partes = {};
        try (Scanner sc = new Scanner(new File("clientes.csv"))) {
            while (sc.hasNextLine()) { 
                String linea = sc.nextLine();
                partes = linea.split(";");
                if (codigo.equals(partes[necesidad])){
                    return partes;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error"); // Manejo de errores si el archivo no se encuentra
        }
        return partes;
    }

    /**
     * Modifica los datos de un cliente en el archivo "clientes.csv".
     * @param dato El código del cliente a modificar.
     */    
    public void ModificarCliente(String dato){
        File archivo = new File("clientes.csv");
        File archivotemp = new File(archivo.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo));
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivotemp))) {

            String linea;
            String[] partes;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
                partes = linea.split(";");
                
                // Escribir la línea en el archivo temporal si no coincide con la línea a eliminar
                if (!partes[0].trim().equals(dato)) {
                    System.out.println(1);
                    writer.write(linea);
                    writer.newLine(); // Añadir nueva línea
                } else {
                    System.out.println(2);
                    writer.write(this.idCliente+";"+this.nombre+";"+this.apellidos+";"+this.telefono+";"+this.correo+";"+this.provincia+";"+this.canton+";"+this.distrito+";"+this.fecha+";");
                    writer.newLine();
                }
            }
            JOptionPane.showMessageDialog(null, "Modificado correctamente");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eliminar el archivo original
        if (!archivo.delete()) {
            System.out.println("No se pudo eliminar el archivo original");
            return;
        }

        // Renombrar el archivo temporal al nombre del archivo original
        if (!archivotemp.renameTo(archivo)) {
            System.out.println("No se pudo renombrar el archivo temporal");
        }

    }

    /**
     * Elimina un cliente del archivo "clientes.csv".
     * @param codigo El código del cliente a eliminar.
     */    
    public void EliminarCliente(String codigo){
        File inputFile = new File("clientes.csv");
        File tempFile = new File(inputFile.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String linea;
            String[] partes; 
            
            while ((linea = reader.readLine()) != null) {
                partes = linea.split(";");
                
                // Solo escribir la línea si no es la que queremos eliminar
                if (!partes[0].trim().equals(codigo)) {
                    writer.write(linea);
                    writer.newLine();
                }
            }
            
            JOptionPane.showMessageDialog(null, "Cliente eliminado");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eliminar el archivo original
        if (!inputFile.delete()) {
            System.out.println("No se pudo eliminar el archivo original");
            return;
        }

        // Renombrar el archivo temporal al nombre del archivo original
        if (!tempFile.renameTo(inputFile)) {
            System.out.println("No se pudo renombrar el archivo temporal");
        }
    
    
    }
    
}
