/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Presentacion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * La clase Productos gestiona las operaciones relacionadas con los productos de una tienda.
 * Permite agregar, buscar, modificar y eliminar productos almacenados en un archivo CSV.
 */
public class Productos {
    
    //Atributos
    
    /**
     * Identificador único del artículo.
     */
    private int idArticulo;
    /**
     * Código del tipo de artículo.
     */
    private int codTipo;

    private String nombre;

    private String tipo;

    private int tamaño;

    private String marca;

    private int precio;
    
    //Métodos
    
    //Metodos set y get

    /**
     * Obtiene el identificador del artículo.
     * @return el idArticulo del producto.
     */    
    public int getIdArticulo() {
        return idArticulo;
    }
    /**
     * Establece el identificador del artículo.
     * @param idArticulo Identificador único del producto.
     */
    public void setIdArticulo(int idArticulo) {
        this.idArticulo = idArticulo;
    }
    // (Los métodos restantes "getter" y "setter" siguen este formato...)
    public int getCodTipo() {
        return codTipo;
    }

    public void setCodTipo(int codTipo) {
        this.codTipo = codTipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getTamaño() {
        return tamaño;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }


    //Da error con JavaDoc
    //Agrega un producto al archivo "productos.csv".
    //Si el archivo no existe, se crea automáticamente.
    public void AgregarProducto(){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("productos.csv", true))) {
            writer.write(this.idArticulo+";"+this.codTipo+";"+this.nombre+";"+this.tipo+";"+this.tamaño+";"+this.marca+";"+this.precio+";");
            writer.newLine();  // Nueva línea
        } catch (IOException e) {
            System.out.println("Error");  // Manejo de errores si el archivo no se puede escribir
        }
    }

    //Da error con JavaDoc  
    //Crea el archivo "productos.csv" si no existe.
    public void CrearArchivo(){
        try {
            File archivo = new File("productos.csv");
            
            //vamos a verificar si el archivo existe
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado con éxito: " + archivo.getName());
            } else {
                System.out.println("El archivo ya existe.");
            }
            
        } catch (IOException ex) {
            System.out.println("Se produjo un error");
        }
    }

    /**
     * Busca un producto en el archivo "productos.csv" por un campo específico.
     * 
     * @param codigo Valor del campo a buscar.
     * @param necesidad Índice del campo en el archivo CSV (0 para idArticulo, etc.).
     * @return Un arreglo con los datos del producto encontrado, o vacío si no se encuentra.
     */    
    public String[] BuscarProducto(String codigo, int necesidad){
        String[] partes = {};
        try (Scanner sc = new Scanner(new File("productos.csv"))) {
            while (sc.hasNextLine()) { 
                String linea = sc.nextLine();
                partes = linea.split(";");
                if (codigo.equals(partes[necesidad])){
                    return partes;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error"); // Manejo de errores si el archivo no se encuentra
        }
        return partes;
    }

    /**
     * Modifica los datos de un producto en el archivo "productos.csv".
     * 
     * @param dato Identificador del producto a modificar.
     */    
    public void ModificarProducto(String dato){
        File archivo = new File("productos.csv");
        File archivotemp = new File(archivo.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo));
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivotemp))) {

            String linea;
            String[] partes;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
                partes = linea.split(";");
                
                // Escribir la línea en el archivo temporal si no coincide con la línea a eliminar
                if (!partes[0].trim().equals(dato)) {
                    System.out.println(1);
                    writer.write(linea);
                    writer.newLine(); // Añadir nueva línea
                } else {
                    System.out.println(2);
                    writer.write(this.idArticulo+";"+this.codTipo+";"+this.nombre+";"+this.tipo+";"+this.tamaño+";"+this.marca+";"+this.precio+";");
                    writer.newLine();
                }
            }
            JOptionPane.showMessageDialog(null, "Modificado correctamente");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eliminar el archivo original
        if (!archivo.delete()) {
            System.out.println("No se pudo eliminar el archivo original");
            return;
        }

        // Renombrar el archivo temporal al nombre del archivo original
        if (!archivotemp.renameTo(archivo)) {
            System.out.println("No se pudo renombrar el archivo temporal");
        }

    }

    /**
     * Elimina un producto del archivo "productos.csv".
     * 
     * @param codigo Identificador del producto a eliminar.
     */    
    public void EliminarProductos(String codigo){
        File inputFile = new File("productos.csv");
        File tempFile = new File(inputFile.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String linea;
            String[] partes; 
            
            while ((linea = reader.readLine()) != null) {
                partes = linea.split(";");
                
                // Solo escribir la línea si no es la que queremos eliminar
                if (!partes[0].trim().equals(codigo)) {
                    writer.write(linea);
                    writer.newLine();
                }
            }
            
            JOptionPane.showMessageDialog(null, "Producto eliminado");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eliminar el archivo original
        if (!inputFile.delete()) {
            System.out.println("No se pudo eliminar el archivo original");
            return;
        }

        // Renombrar el archivo temporal al nombre del archivo original
        if (!tempFile.renameTo(inputFile)) {
            System.out.println("No se pudo renombrar el archivo temporal");
        }
    
    
    }
    
}
