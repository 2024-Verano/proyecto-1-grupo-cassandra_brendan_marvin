/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Presentacion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * Clase que representa los diferentes tipos de productos disponibles.
 * Se encarga de gestionar la información básica de cada tipo de producto, como su código y nombre.
 * También proporciona métodos para realizar operaciones CRUD (crear, leer, actualizar y eliminar)
 * sobre los tipos de productos almacenados en un archivo CSV.
 */
public class TiposDeProductos {
    
    //Atributos
    /**
     * Código único del tipo de producto.
     */
    private int codigo;
    /**
     * Nombre del tipo de producto.
     */
    private String nombre;
    
    //Metodos
    
    // Métodos get y set
    /**
     * Obtiene el código del tipo de producto.
     * 
     * @return el código del tipo de producto.
     */
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Métodos principales
    /**
     * Agrega un nuevo tipo de producto al archivo "tiposdeproductos.csv".
     * Cada tipo de producto se almacena en una línea separada.
     */    
    public void AgregarTiposDeProductos(){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("tiposdeproductos.csv", true))) {
            writer.write(this.codigo+";"+this.nombre+";");
            writer.newLine();  // Nueva línea
        } catch (IOException e) {
            System.out.println("Error");  // Manejo de errores si el archivo no se puede escribir
        }
    }

    //Da error con JavaDoc
    //Crea el archivo "tiposdeproductos.csv" si no existe.
    public void CrearArchivo(){
        try {
            File archivo = new File("tiposdeproductos.csv");
            
            //vamos a verificar si el archivo existe
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado con éxito: " + archivo.getName());
            } else {
                System.out.println("El archivo ya existe.");
            }
            
        } catch (IOException ex) {
            System.out.println("Se produjo un error");
        }
    }

    /**
     * Busca un tipo de producto en el archivo "tiposdeproductos.csv" basado en el código o índice.
     * 
     * @param codigo el valor que se busca.
     * @param necesidad el índice que indica el atributo por el cual buscar (0 para código, 1 para nombre).
     * @return un arreglo con los datos del tipo de producto encontrado, o un arreglo vacío si no se encuentra.
     */    
    public String[] BuscarTiposDeProductos(String codigo, int necesidad){
        String[] partes = {};
        try (Scanner sc = new Scanner(new File("tiposdeproductos.csv"))) {
            while (sc.hasNextLine()) { 
                String linea = sc.nextLine();
                partes = linea.split(";");
                if (codigo.equals(partes[necesidad])){
                    return partes;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error"); // Manejo de errores si el archivo no se encuentra
        }
        return partes;
    }

    /**
     * Modifica los datos de un tipo de producto en el archivo "tiposdeproductos.csv".
     * 
     * @param dato el código del tipo de producto a modificar.
     */    
    public void ModificarTiposDeProductos(String dato){
        File archivo = new File("tiposdeproductos.csv");
        File archivotemp = new File(archivo.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo));
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivotemp))) {

            String linea;
            String[] partes;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
                partes = linea.split(";");
                
                // Escribir la línea en el archivo temporal si no coincide con la línea a eliminar
                if (!partes[0].trim().equals(dato)) {
                    System.out.println(1);
                    writer.write(linea);
                    writer.newLine(); // Añadir nueva línea
                } else {
                    System.out.println(2);
                    writer.write(this.codigo+";"+this.nombre+";");
                    writer.newLine();
                }
            }
            JOptionPane.showMessageDialog(null, "Modificado correctamente");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eliminar el archivo original
        if (!archivo.delete()) {
            System.out.println("No se pudo eliminar el archivo original");
            return;
        }

        // Renombrar el archivo temporal al nombre del archivo original
        if (!archivotemp.renameTo(archivo)) {
            System.out.println("No se pudo renombrar el archivo temporal");
        }

    }

    /**
     * Elimina un tipo de producto del archivo "tiposdeproductos.csv".
     * 
     * @param codigo el código del tipo de producto a eliminar.
     */    
    public void EliminarTiposDeProductos(String codigo){
        File inputFile = new File("tiposdeproductos.csv");
        File tempFile = new File(inputFile.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String linea;
            String[] partes; 
            
            while ((linea = reader.readLine()) != null) {
                partes = linea.split(";");
                
                // Solo escribir la línea si no es la que queremos eliminar
                if (!partes[0].trim().equals(codigo)) {
                    writer.write(linea);
                    writer.newLine();
                }
            }
            
            JOptionPane.showMessageDialog(null, "Cliente eliminado");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eliminar el archivo original
        if (!inputFile.delete()) {
            System.out.println("No se pudo eliminar el archivo original");
            return;
        }

        // Renombrar el archivo temporal al nombre del archivo original
        if (!tempFile.renameTo(inputFile)) {
            System.out.println("No se pudo renombrar el archivo temporal");
        }
    
    
    }
    
}
